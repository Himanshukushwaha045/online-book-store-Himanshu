from django.shortcuts import render,redirect
from django.contrib import messages
from mainapp.models import *
from adminapp.models import *
# Create your views here.
def userdash(request):
    if 'userid' not in request.session:
        messages.error(request,"Your are not logged in")
        return redirect('login')
    userid = request.session.get('userid')
    user = UserInfo.objects.get(email= userid)
    

    context = {
        'userid': userid,
        'user': user,
    }
    return render(request, 'userdash.html',context)

def userlogout(request):
    if 'userid' in request.session:
        del request.session['userid']
        messages.success(request, "You are logged out.")
        return redirect('index')
    else:
        messages.error(request, "Login first")
        return redirect('index')
    

def userprofile(request):
    if 'userid' not in request.session:
        messages.error(request,"Your are not logged in")
        return redirect('login')
    userid = request.session.get('userid')
    user = UserInfo.objects.get( email= userid)
    

    context = {
        'userid': userid,
        'user': user,
    }
    return render(request, 'userprofile.html',context)    


def editprofile(request):
    if 'userid' not in request.session:
        messages.error(request,"Your are not logged in")
        return redirect('login')
    userid = request.session.get('userid')
    user = UserInfo.objects.get(email = userid)
    

    context = {
        'userid': userid,
        'user': user,
    }
    return render(request,'editprofile.html',context)

def viewcart(request):
    if 'userid' not in request.session:
        messages.error(request,"Your are not logged in")
        return redirect('login')
    userid = request.session.get('userid')
    user = UserInfo.objects.get(email= userid)
    

    context = {
        'userid': userid,
        'user': user,
    }
    return render(request, 'viewcart.html',context)

def userorders(request):
    if 'userid' not in request.session:
        messages.error(request,"Your are not logged in")
        return redirect('login')
    userid = request.session.get('userid')
    user = UserInfo.objects.get(email= userid)
    

    context = {
        'userid': userid,
        'user': user,
    }
    return render(request, 'userorders.html',context)