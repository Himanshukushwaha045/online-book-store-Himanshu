from django.shortcuts import render,redirect
from django.contrib import messages
from mainapp.models import *
from .models import *
# Create your views here.
def admindash(request):
    if 'adminid' not in request.session:
        messages.error(request,"Your are not logged in")
        return redirect('adminlogin')
    adminid = request.session.get('adminid')
    context = {
        'adminid': adminid,
    }
    return render(request, 'admindash.html',context)

def adminlogout(request):
    if 'adminid' in request.session:
        del request.session['adminid']
        messages.success(request, "You are logged out.")
        return redirect('adminlogin')
    else:
        return redirect('adminlogin')
    

def viewenqs(request):
    if 'adminid' not in request.session:
        messages.error(request,"Your are not logged in")
        return redirect('adminlogin')
    adminid = request.session.get('adminid')
    enqs = Enquiry.objects.all()
    context = {
        'adminid': adminid,
        'enqs' : enqs,
    }
    return render(request, 'viewenqs.html',context)

def delenq(request,id):
    if 'adminid' not in request.session:
        messages.error(request,"Your are not logged in")
        return redirect('adminlogin')
    enq = Enquiry.objects.get(id=id)
    enq.delete()
    messages.success(request, "Enquiry deleted successfully")
    return redirect('viewenqs')

def addcat(request):
    if 'adminid' not in request.session:
        messages.error(request,"Your are not logged in")
        return redirect('adminlogin')
    adminid = request.session.get('adminid')
    context = {
        'adminid': adminid,
    }
    if request.method == "POST":
        name = request.POST.get('name')
        description = request.POST.get('description')
        cat = Category(name=name, description=description)
        cat.save()
        messages.success(request, "Category added successfully")
        return redirect('addcat')
    return render(request, 'addcat.html',context)

def viewcat(request):
    if 'adminid' not in request.session:
        messages.error(request,"Your are not logged in")
        return redirect('adminlogin')
    adminid = request.session.get('adminid')
    context = {
        'adminid': adminid,
    }
    return render(request, 'viewcat.html',context)

def addbook(request):
    if 'adminid' not in request.session:
        messages.error(request,"Your are not logged in")
        return redirect('adminlogin')
    adminid = request.session.get('adminid')
    cats = Category.objects.all()
    context = {
        'adminid': adminid,
        'cats':cats
    }
    if request.method == "POST":
        title = request.POST.get('title')
        author = request.POST.get('author')
        category = request.POST.get('category')
        cat = Category.objects.get(id=category)  # must add
        description = request.POST.get('description')
        original_price = request.POST.get('original_price')
        price = request.POST.get('price')
        published_date = request.POST.get('published_date')
        language = request.POST.get('language')
        cover_image = request.FILES.get('cover_image')
        stock = request.POST.get('stock')
        b = Book(
            title=title,
            author = author,
            category = cat,
            description=description,
            original_price=original_price,
            price=price,
            published_date = published_date,
            language = language,
            cover_image = cover_image,
            stock = stock
        )
        b.save()
        messages.success(request, "Book added successfully")
        return redirect('addbook')
    return render(request, 'addbook.html',context)

def viewbook(request):
    if 'adminid' not in request.session:
        messages.error(request,"Your are not logged in")
        return redirect('adminlogin')
    adminid = request.session.get('adminid')
    books = Book.objects.all()
    context = {
        'adminid': adminid,
        'books':books
    }
    return render(request, 'viewbook.html',context)